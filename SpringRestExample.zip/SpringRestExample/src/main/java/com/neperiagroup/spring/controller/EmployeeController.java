package com.neperiagroup.spring.controller;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.ResponseBody;

import com.neperiagroup.spring.model.Employee;


/**
 * Handles requests for the Employee service.
 */
@Controller
public class EmployeeController {
	
private static final Logger logger = LoggerFactory.getLogger(EmployeeController.class);
	
	//Map to store employees, ideally we should use database
	Map<Integer, Employee> empData = new HashMap<Integer, Employee>();
	
	SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
	 
	
	
	 @RequestMapping(value = EmpRestURIConstants.GET_EMP, method = RequestMethod.GET)
	 public ResponseEntity<Employee> handle() {
	   HttpHeaders responseHeaders = new HttpHeaders();
	   	Employee emp = new Employee();
	   	emp.setId(265);
		emp.setName("Daviano");
		emp.setSurname("Amar�");
		emp.setEmail("davianoamaru@gmail.com");
		emp.setPassword("password");
		emp.setCreatedDate(format.format(new Date()));
		
		System.out.println("empData: "+empData);
		System.out.println("emp: "+emp);
		return new ResponseEntity<Employee> (emp, responseHeaders, HttpStatus.OK);
	 }
	
	 @RequestMapping(value = EmpRestURIConstants.POST_EMP, method = RequestMethod.POST)
		public ResponseEntity<Employee> post(@RequestBody Employee emp) {
		 System.out.println("POST_PROVA");
		 logger.info("Start createEmployee.");
		 HttpHeaders responseHeaders = new HttpHeaders();
		 System.out.println(emp);
		 emp.setCreatedDate(format.format(new Date()));
		 empData.put(emp.getId(), emp);
		 return new ResponseEntity<Employee> (emp, responseHeaders, HttpStatus.CREATED);
		}
	 
	 @RequestMapping(value = EmpRestURIConstants.GET_EMP_PARAM, method = RequestMethod.GET)
		public ResponseEntity<Employee> getEmpEntity(@PathVariable("id") int empId) {
			System.out.println("sono qui: getEmpEntity");
			System.out.println("empId: "+empId);
			HttpHeaders responseHeaders = new HttpHeaders();
			
			return new ResponseEntity<Employee> (empData.get(empId), responseHeaders, HttpStatus.OK);
		}
	
	 @RequestMapping(value = EmpRestURIConstants.GET_ALL_EMP_ENTITY, method = RequestMethod.GET)
		public ResponseEntity<List<Employee>> getAllEmpEntity() {
		 System.out.println("sono qui: getAllEmpEntity");
		 logger.info("Start getAllEmployees.");
		 List<Employee> emps = new ArrayList<Employee>();
		 Set<Integer> empIdKeys = empData.keySet();
		 System.out.println("empIdKeys: "+empIdKeys);
		 
		 HttpHeaders responseHeaders = new HttpHeaders();
		 for(Integer i : empIdKeys){	
			 emps.add(empData.get(i));
			 System.out.println("emps: "+emps);
		 }
		 return  new ResponseEntity<List<Employee>> (emps, responseHeaders, HttpStatus.OK);
		}
	 
	 @RequestMapping(value = EmpRestURIConstants.DELETE_EMP_ENTITY, method = RequestMethod.PUT)
		public ResponseEntity <Employee> deleteEmpEntity(@PathVariable("id") int empId) {
			System.out.println("Api-delete");
			logger.info("Start deleteEmployee.");
			HttpHeaders responseHeaders = new HttpHeaders();
			Employee emp = empData.get(empId);
			empData.remove(empId);
			return new ResponseEntity <Employee> (emp, responseHeaders, HttpStatus.OK);
		}
}
