package com.neperiagroup.spring.controller;

public class EmpRestURIConstants {

	public static final String GET_EMP  = "/rest/emp";
	public static final String POST_EMP  = "/rest/emp/create";
	public static final String GET_EMP_PARAM  = "/rest/emp/{id}";
	public static final String GET_ALL_EMP_ENTITY  = "/rest/emps";
	public static final String DELETE_EMP_ENTITY  = "/rest/delete/emp/{id}";
}
