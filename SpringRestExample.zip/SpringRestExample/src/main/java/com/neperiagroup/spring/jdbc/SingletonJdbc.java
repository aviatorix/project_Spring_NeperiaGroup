package com.neperiagroup.spring.jdbc;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;



public class SingletonJdbc {
	static final String url = "jdbc:mysql://localhost:3306/";
	static final String dbName = "springmvc";
	static final String driver = "com.mysql.jdbc.Driver";
	static final String userName = "root";

	private static SingletonJdbc ObjJdbc;
	private  Connection con;
	
	
	private SingletonJdbc() {
		System.out.println("Connection Database start");
		con = createConnection();
	}

	@SuppressWarnings("rawtypes")
	public Connection createConnection() {
		Connection connection = null;

		try {
			// Load the JDBC driver
			Class driver_class = Class.forName(driver);
			Driver driver = (Driver) driver_class.newInstance();
			DriverManager.registerDriver(driver);
			connection = DriverManager.getConnection(url + dbName + "?user="+ userName);


		} catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} catch (IllegalAccessException ex) {
			ex.printStackTrace();
		} catch (InstantiationException ex) {
			ex.printStackTrace();
		}
		return connection;
	}

	/*
	 * Create a static method to get instance.
	 */
	public static SingletonJdbc getInstance() {
		if (ObjJdbc == null) {
			ObjJdbc = new SingletonJdbc();
		}
		return ObjJdbc;
	}

	public ResultSet executeQuery(String sql) {

		System.out.println(sql);
		ResultSet res;
		try {
			Statement statement = con.createStatement();
			res = statement.executeQuery(sql);

			return res;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	public static void main (String [] args) {
		
		String sql = "INSERT INTO `user` (name, surname,  email, password, regDate) VALUES ('giovanni', 'mallo', 'giovannimallo@gmail.com', 123, '2018-09-12')";
		SingletonJdbc start = SingletonJdbc.getInstance();
		System.out.println(sql);
		try {
			Statement prepared =  start.createConnection().prepareStatement(sql);
			prepared.executeUpdate(sql);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(sql);
			e.printStackTrace();
		}
	}

}
